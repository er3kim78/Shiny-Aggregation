

library(shiny)
require(sqldf)
require(plyr)
require(tcltk)
require(data.table)
require(ggvis)
require(dplyr)



options(shiny.maxRequestSize=-1)

# declared the agg_final data frame in global.R


shinyServer(function(input, output) {
  
    #get the data file selected
    dataInput <- reactive({
      
      inFile <- input$file
      
      if (is.null(inFile))
        return(NULL)
      
      read.csv(inFile$datapath)
      
    })
  
    # display available date range
    output$avail_date_range <- renderPrint({
      
      dataset<-dataInput()
      
      if(!is.null(dataset)){
        
        range(as.Date(as.character(dataset$From), format="%m/%d/%Y"))  
      }
    })
    
    
    # calculate the aggregation, based on the input file and the aggregation level selected.
    # press button GO to recalculate after selection is made
    agg_final <- reactive({
      
      input$calcButton
      
      # assign the dynamically chosen dataset to a variable
      dataset <- dataInput()
      
      if(!is.null(dataset)){
        
        #msgbox <- tkmessageBox(title="Info", message="into the data aggregation part", icon="info", type="ok")
              
        # Cost cannot have commas
        dataset$Cost <- as.numeric(as.character(gsub(",", "", dataset$Cost, fixed=TRUE)))
        
        # format dates from 'factor' to 'date'
        dataset$From<-as.Date(as.character(dataset$From), format="%m/%d/%Y")
        
        # determine available date range (get min and max dates from data set)
        
        min_date_avail <- as.Date(min(dataset$From), format="%Y-%m-%d")
        max_date_avail <- as.Date(max(dataset$From), format="%Y-%m-%d") 
        
        # isolate the date input box, so the recalculation of the metrics doesn't trigger with each of the dates entered
        isolate({
          # start date, from input
          min_date_input <- as.Date(input$daterange[1], format="%Y-%m-%d")
          # end date, from input
          if (input$daterange[2] >= input$daterange[1]){
            max_date_input <- as.Date(input$daterange[2], format="%Y-%m-%d")
          } else
            max_date_input <- as.Date(input$daterange[1], format="%Y-%m-%d")
          #})
          
          
          # run the data aggregation, depending on which level was chosen
          
          levels_available <- c("Account", 
                                "Account, Campaign")
  
          level_selected <- renderText({ input$level_selected })
          
          if(level_selected() == "Account"){
            agg_level <- levels_available[[1]]
            
            rawdata_datatable <- data.table(dataset)
            
            setkey(rawdata_datatable, From, Account)
            
            agg_datatable <- rawdata_datatable[,list(Imps=sum(Impr),
                                                     Clicks=sum(Clicks),
                                                     Cost=sum(Cost)),
                                               by=list(From, Account)
                                               ]
            agg <- data.frame(agg_datatable)
            
            
          } else if(level_selected() == "Campaign"){
            agg_level <- levels_available[[2]]
            
            rawdata_datatable <- data.table(dataset)
            
            setkey(rawdata_datatable, From, Account, Campaign)
            
            agg_datatable <- rawdata_datatable[,list(Imps=sum(Impr),
                                                     Clicks=sum(Clicks),
                                                     Cost=sum(Cost)),
                                               by=list(From, Account,Campaign)
                                               ]
            agg <- data.frame(agg_datatable)
            
            
          } 
          
          
          if(min_date_input == Sys.Date() && max_date_input==Sys.Date()){
            
            qry <- paste("Select ", agg_level, 
                         ", sum(Imps) as Imps, sum(Clicks) as Clicks, sum(Cost) as Cost  
                           FROM agg 
                           WHERE [From] BETWEEN ", as.numeric(min_date_avail), " AND ", as.numeric(max_date_avail), 
                         " GROUP BY ", agg_level, " ORDER BY Cost DESC LIMIT ", input$obs, sep="")
            sqldf(qry)
            
            
          } else
            qry <- paste("Select ", agg_level, 
                         ", sum(Imps) as Imps, sum(Clicks) as Clicks, sum(Cost) as Cost  
                           FROM agg
                           WHERE [From] BETWEEN ", as.numeric(min_date_input), " AND ", as.numeric(max_date_input), 
                         " GROUP BY ", agg_level, " ORDER BY Cost DESC LIMIT ", input$obs, sep="")
            sqldf(qry) 
          
        }) #isolate 
      } #if
      
    })
  
  
    # Show the first "n" observations
    output$table_view <- renderTable({
      agg_final()
    })  
    
    
    # construct plot
    reactive({
      
      if(!is.null(agg_final())){
        
       msgbox <- tkmessageBox(title="Info", message="into the first reactive statement", icon="info", type="ok")
          
        reactive({  
          graphdata <- agg_final()     
          
          msgbox <- tkmessageBox(title="Info", message="into the second reactive statement", icon="info", type="ok")
          
          xvar<-reactive({
            switch(input$xvar, 
                   "Clicks" = graphdata$Clicks,
                   "Cost" = graphdata$Cost,
                   "Impr" = graphdata$Impr)
          })
          
          yvar<-reactive({
            switch(input$yvar, 
                   "Clicks" = graphdata$Clicks,
                   "Cost" = graphdata$Cost,
                   "Impr" = graphdata$Impr)
          })
          
          graphdata %>% 
            ggvis(~xvar, ~yvar, opacity:=0.4) %>%
            layer_points()
        
        }) %>% bind_shiny("plot1")  
        
      } # end if
      
    }) 
        
}) #end shiny function


