


library(shiny)


shinyUI(fluidPage(

  titlePanel("Shiny Tables Example"),
  
  # Sidebar with controls to select a dataset and specify the
  # number of observations to view
  sidebarLayout(
    sidebarPanel(
      
      fileInput("file", label = h4("Input file: "), accept='.csv'),
      
            
      selectInput("level_selected", label="Choose an aggregation level, then press GO:", 
                  choices = c("Account", "Campaign"),
                  selected="Account"),
      
      column(8,numericInput("obs", "Number of observations to view:", 10)),
      
      fluidRow(
        column(7,dateRangeInput("daterange", label="Date range:", 
                                start = NULL, end = NULL)),
        br(), 
        column(1,actionButton("calcButton", "Go"))
      )
            
    ),  #closes sidebarPanel
    
    
    # One tab to the table showing the data aggregation
    # one tab for the plot of the data aggregation
    mainPanel(
      tabsetPanel(
        tabPanel("data-aggregation",
                 fluidRow(
                   column(3,h4(helpText("Date range available:"))),
                   column(4, verbatimTextOutput("avail_date_range"))
                         ),
                 tableOutput("table_view")
                 )

        ,tabPanel("chart",
                 fluidRow(
                   column(4,wellPanel(selectInput("xvar", "X-Axis Variables", choices=c("Clicks", "Imps", "Cost"), selected = "Clicks"),
                                      selectInput("yvar", "Y-Axis Variable", choices=c("Clicks", "Imps", "Cost"), selected = "Cost")
                                      )
                          )),
                 fluidRow(column(12, ggvisOutput("plot1")))
                  
                 ) # end tabPanel chart
      )  # end tab panel
    )  # closes mainPanel
    
  )  # closes sidebarLayout
  
))  # closes fluidPage and shinyUI


