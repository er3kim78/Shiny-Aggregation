

# there should be a global variable that hold the aggregation
# that is calculated as part of the view variable
# that could then be passed to the plot output variable


# declare an empty data frame to hold the aggregation calculated in table_view
agg_final <- data.frame()